#' UMAP-transform reference cohort
#'
#' Function to create the data required for plotting an UMAP of the reference cohort,
#' and paving the way for transforming new samples into the same sample space by
#' saving the transformation-model and ribo-depletion correction model.
#'
#' Please note that the tumor domain, type and subtype all need to be specified within the metadata.
#'
#' @param countDataRef Matrix containing the RNA-transcript per million data. Patients are in the columns,
#' different genes in the rows.
#' @param metaDataRef Metadata file containing the links between the patients and
#' the tumor (sub)type diagnosis within the reference cohort.
#' @param classColumn Column in the metadata file that contains the tumor subtype labels.
#' @param higherClassColumn Column in the metadata file that contains the tumor type labels.
#' @param domainColumn Column in the metadata file that contains the tumor domain labels.
#' @param abbreviations Dataframe containing the links between the tumor (sub)type,
#' the abbreviation required in the plot, and the domain.
#' @param proteinFile In which directory can we find the file specifying the names of protein-coding genes within our dataset?
#' @param whichSeed For reproducibility, the seed can be specified with this parameter.
#' @param higherClassColumn Column in the metadata file that contains the tumor type labels.
#' @param correctRibo Do you want to perform a correction for the ribodepletion protocol on your dataset?
#' Default = FALSE, giving only the tumor type labels with the associated abbreviations.
#'
#' @return List containing the UMAP-transformed datapoints ($dataUMAP), and the ribodepletion correction model ($riboModelList).
#' @export
#' @import umap dplyr magrittr

createUMAPcohort <- function(countDataRef,
                             metaDataRef,
                             classColumn,
                             higherClassColumn,
                             domainColumn,
                             correctRibo = T,
                             abbreviations = NA,
                             proteinCodingGenes,
                             whichSeed = 1) {

  `%notin%` <- Negate(`%in%`)
  if (missing("classColumn") | missing("higherClassColumn") | missing("domainColumn")) {
    stop("You need to input the parameter in classColumn, higherClassColumn and domainColumn.")
  }

  if (nrow(metaDataRef) != ncol(countDataRef)) {
    stop("The number of samples do not match between the metadata and the count data. Please make sure you include all same samples in both objects.")
  } else if (all(rownames(metaDataRef) %notin% colnames(countDataRef))) {
    stop("Your input data is not as required. Please make sure your patient IDs are within the row names of the metadata, and in the column names of the count data")
  }

  if (is.numeric(countDataRef) != T) {
    stop("Your input data is not as required. Please make sure your countDataRef object only contains numerical count data and is a matrix.
         Non-available measurements are not allowed.")

  }

  if (is.na(abbreviations)[1]) {

    abbreviations <- metaDataRef[, c(domainColumn, classColumn, higherClassColumn)] %>% unique()
    abbreviations$abbreviationSubtype <- abbreviations[,classColumn]
    abbreviations$abbreviationTumorType <- abbreviations[,higherClassColumn]

    print("You have not supplied any abbreviations (abbreviations). If you would like to use abbreviations,
          please generate a dataframe with the following columns and abbreviations within abbreviationSubtype and abbreviationTumorType:")
    print(abbreviations[1:4,])
  }

  if (correctRibo == T) {

  set.seed(whichSeed)
  riboModelList <- riboCorrectCounts(data = countDataRef,
                                     proteinCodingGenes = proteinCodingGenes,
                                     outputDir = ".",
                                     saveRiboModels = F
  )
  countDataRef <- riboModelList$counts
  }
  # Log-transform data
  dataLogRef <- log(countDataRef +1) %>% t() %>% as.data.frame()
  abbreviations %<>% filter(!!sym(classColumn) %in% unique(metaDataRef[, classColumn]),
                            !!sym(higherClassColumn) %in% unique(metaDataRef[, higherClassColumn])
                            )
  metaDataJoined <- left_join(metaDataRef, abbreviations[,c(classColumn, "abbreviationTumorType", "abbreviationSubtype")])

  rownames(metaDataJoined) <- rownames(metaDataRef)
  metaDataRef <- metaDataJoined

  set.seed(whichSeed)
  dataLogUMAP <- dataLogRef %>%
    select(where(is.numeric)) %>%
    umap::umap()
  colnames(dataLogUMAP$layout) <- c("UMAP1", "UMAP2")

  dataUMAP <- dataLogUMAP$layout %>%
    as.data.frame()

  dataUMAP$abbreviationTumorType <- metaDataRef[rownames(dataUMAP), "abbreviationTumorType"]
  dataUMAP$abbreviationSubtype <- metaDataRef[rownames(dataUMAP), "abbreviationSubtype"]
  dataUMAP$Domain <- metaDataRef[rownames(dataUMAP), domainColumn]


  dataUMAP$subclass <- metaDataRef[rownames(dataUMAP), higherClassColumn]
  dataUMAP$subtype <- metaDataRef[rownames(dataUMAP), classColumn]


  #dataUMAP <- cbind(dataUMAP, dataLogRef[, c("subclass","Domain", "abbreviation"), drop = F])
  dataUMAPList <- list(dataUMAP = dataUMAP,
                       abbreviations = abbreviations)

  if (correctRibo == T) {
    dataUMAPList$riboModelList <- riboModelList
  }
  return(dataUMAPList)

}
